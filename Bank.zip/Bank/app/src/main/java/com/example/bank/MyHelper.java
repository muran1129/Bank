package com.example.bank;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MyHelper extends SQLiteOpenHelper {

   private MyHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
   private static SQLiteOpenHelper mInstance;
//   单例模式  只创建一个mInsatnce
   public static SQLiteOpenHelper getmInstance(Context context)
   {
       if(mInstance==null)
       {
           mInstance=new MyHelper(context,"my.db",null,1);
       }
      return mInstance;

   }
//创建数据库使用 只运行一次
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
      String sql="create table phonenumber_password (_id integer primary key autoincrement,phonenumber text,password text)";
      sqLiteDatabase.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
