package com.example.bank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PasswordLog extends AppCompatActivity implements View.OnClickListener {
    private Button mbtn_log,mbtn_register;
    private EditText mev_phonenumber,mev_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_log);
        mbtn_log=findViewById(R.id.btn_log);
        mbtn_log.setOnClickListener(this);
        mev_phonenumber=findViewById(R.id.ev_phonenumber);
        mev_password=findViewById(R.id.ev_password);
        mbtn_register=findViewById(R.id.btn_register);
        mbtn_register.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.btn_log:
                //对比用户名密码
                create_phonenumber_password(view);
                String phonenumber=mev_phonenumber.getText().toString();
                String password=query_phonenumber_password(view,phonenumber);
                String get_password=mev_password.getText().toString();

                if(get_password.equals(password))
                {
                    //成功
                    Toast.makeText(PasswordLog.this, "密码正确", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(PasswordLog.this,PersonInfo.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(PasswordLog.this, "密码错误", Toast.LENGTH_SHORT).show();
                }

                break;
            case R.id.btn_register:

                insert_phonenumber_password(view);

                break;
            default:
                throw new IllegalStateException("Unexpected value: " + view.getId());
        }
    }
    public   void  create_phonenumber_password(View view)
    {
        SQLiteOpenHelper myhelper =MyHelper.getmInstance(this);
        SQLiteDatabase phonenumber_password=myhelper.getReadableDatabase();
    }
    public String  query_phonenumber_password(View view,String phonenumber)
    {
        SQLiteOpenHelper myhelper =MyHelper.getmInstance(this);
        SQLiteDatabase phonenumber_password=myhelper.getReadableDatabase();
        String sql="select password from phonenumber_password where phonenumber=?";
        Cursor cursor=phonenumber_password.rawQuery(sql, new String[]{phonenumber});
        String password="";
        while(cursor.moveToNext())
        {
           password=cursor.getString(cursor.getColumnIndex("password"));
            Toast.makeText(PasswordLog.this, password, Toast.LENGTH_SHORT).show();

        }
        cursor.close();
        phonenumber_password.close();
        return password;
    }
    public void insert_phonenumber_password(View view)
    {
        SQLiteOpenHelper myhelper =MyHelper.getmInstance(this);
        SQLiteDatabase phonenumber_password=myhelper.getReadableDatabase();

        if(phonenumber_password.isOpen())
        {
            String sql="insert  into phonenumber_password(phonenumber,password) values('19844390545','123456')";
            phonenumber_password.execSQL(sql);

        }
        phonenumber_password.close();
        Toast.makeText(PasswordLog.this, "数据插入好了", Toast.LENGTH_SHORT).show();

    }



}